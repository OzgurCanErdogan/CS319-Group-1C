import java.awt.*;  
import javax.swing.*;  
import java.awt.event.*;

public class SettingsMenu extends JPanel{
	public SettingsMenu( JPanel mainPanel, CardLayout cardLayout){
		JButton but1 = new JButton("hello");
		add(but1);
	
	}
}
